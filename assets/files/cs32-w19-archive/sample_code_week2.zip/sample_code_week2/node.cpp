

#include <iostream>
#include <string>
using namespace std;

class Node{
public:
	Node(int id){
		cout << "Constructor:" << id << endl;
		this->id = id;
	}
	~Node(){
		cout << "Destructor:" << this->id << endl;
	}
private:
	int id;
};

int main(){
	Node node1(31);
	Node* node2 = new Node(32);
	// do something
	return 0;
}
