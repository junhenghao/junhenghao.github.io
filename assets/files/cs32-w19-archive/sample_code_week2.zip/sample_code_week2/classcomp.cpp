#include <iostream>
#include <string>
using namespace std;
 
class A
{
public:
	A(){cout << "A()" << endl;}
	A(int x){cout << "A(" << x << ")" << endl; this->id = x;}
	~A(){cout << "~A("<< this->id <<")" << endl;}
private:
	int id;
};

class B
{
public:
	B():a1(888),a2(444){cout << "B()" << endl;}
	~B(){cout << "~B()" << endl;}
private:
	A a2;
	A a1;
};

int main()
{
	B b;
	return 0;
}
